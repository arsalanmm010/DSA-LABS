#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "node.h"
#include "AVL.h"
#define MAXCHAR 1000

bool bst_search(struct node * root, int key)
{
    /** Complete this function */
    if(root == NULL)
        return false;
    else if(key < root->data)
        return bst_search(root->left, key);
    else if(key > root->data)
        return bst_search(root->right, key);
    else
        return true;

}

bool insert_node(struct node ** ptr, int insert_data)
{
    if(*ptr == NULL) /// We have to insert a new node in the tree now
    {
        struct node * temp = (struct node *) malloc(sizeof(struct node));
        temp->data = insert_data;
        temp->left = NULL;
        temp->right = NULL;
        *ptr = temp;
        printf("\n%d as Root node inserted!", insert_data);
        return(true);
    }

    if(((*ptr)->data > insert_data)) /// data to be inserted to left sub tree
    {
        if((*ptr)->left != NULL)
            insert_node(&(*ptr)->left, insert_data);
        else
        {
            struct node * temp = (struct node *) malloc(sizeof(struct node));
            temp->data = insert_data;
            temp->left = NULL;
            temp->right = NULL;
            (*ptr)->left = temp;
            printf("\n%d inserted to the left of %d!", insert_data, (*ptr)->data);
            return(true);
        }
    }
    else
    {
        if((*ptr)->right != NULL)
            insert_node(&(*ptr)->right, insert_data);
        else
        {
            struct node * temp = (struct node *) malloc(sizeof(struct node));
            temp->data = insert_data;
            temp->left = NULL;
            temp->right = NULL;
            (*ptr)->right = temp;
            printf("\n%d inserted to the right of %d!", insert_data, (*ptr)->data);
            return(true);
        }
    }


    return(true);
}

bool delete_node(struct node * root, int data)
{

    /** Complete this function */
    return(false);
}

bool save_in_order(struct node * root, FILE * fptr)
{
    /** Complete this function */
     if(root == NULL)
        return;
	save_in_order(root->left,fptr);
	fprintf(fptr,"%d\t", root->data);
	save_in_order(root->right,fptr);
}

bool save_pre_order(struct node * root, FILE * fptr)
{
    if(root == NULL)
        return;
    fprintf(fptr,"%d\t", root->data);
	save_pre_order(root->left,fptr);
	save_pre_order(root->right,fptr);
}

bool save_post_order(struct node * root, FILE * fptr)
{
    if(root == NULL)
        return;
	save_post_order(root->left,fptr);
	save_post_order(root->right,fptr);
	fprintf(fptr,"%d\t", root->data);
}

void load_tree(struct node * root, FILE * fptr)
{
    /** Complete this function */
    char str[MAXCHAR];
    char delim[] = "\t";
    while (fgets(str, MAXCHAR, fptr) != NULL)
    {
        char *ptr = strtok(str, delim);

        while(ptr != NULL)
        {
            int value = atoi(ptr);
            ptr = strtok(NULL, delim);
             if(insert_node(root, value) == true)
             {

             }
             else
             {
                printf("\nData insertion failed!");
             }
        }
    }
fclose(fptr);
}

int find_smallest_node(struct node * root)
{
    /** Complete this function */
    struct node * curr= root;
    while(curr != NULL && curr->left != NULL)
        curr = curr -> left;
    return(curr);

}

void print_in_order(struct node * root)
{
    if(root == NULL)
        return;

	print_in_order(root->left);       //Visit left subtree
	printf("%d\t",root->data);  //Print data
	print_in_order(root->right);
}

void print_pre_order(struct node * root)
{
if(root == NULL)
    return;

	printf("%d\t",root->data); // Print data
	print_pre_order(root->left);     // Visit left subtree
	print_pre_order(root->right);    // Visit right subtree

}

void print_post_order(struct node * root)
{
   if(root == NULL)
    return;

	print_post_order(root->left);    // Visit left subtree
	print_post_order(root->right);   // Visit right subtree
	printf("%d\t",root->data); // Print data

}
